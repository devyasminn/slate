"""Infrastructure layer - External implementations."""
