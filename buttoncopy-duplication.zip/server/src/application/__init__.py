"""Application layer - Use cases."""
